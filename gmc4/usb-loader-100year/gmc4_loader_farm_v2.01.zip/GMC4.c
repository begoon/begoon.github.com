// GMC4.c
// GMC-4 AutoKeyIn Module for Type A 
// 2009/08/03
// by maris

#include <avr/io.h>
#include "GMC4.h"

#define GMC4_KEYDDR DDRB
#define GMC4_KEYPORT PORTB
#define GMC4_KEY 0
#define GMC4_KEYMASK 0x1f

#define GMC4_ENDDR DDRB
#define GMC4_ENPORT PORTB
#define GMC4_EN (1 << 6)

//#define GMC4_ADRSET 0x1c
//#define GMC4_INCR   0x14
//#define GMC4_RUN    0x0c
//#define GMC4_RESET  0x04

#define GMC4_ADRSET 0x1c
#define GMC4_INCR   0x18
#define GMC4_RUN    0x14
#define GMC4_RESET  0x10

#define GMC4_WAIT 8000


char GMC4_FLAG;

/*
char GMC4_KEYMAP[16] = {
	0x00,0x01,0x02,0x03,
	0x08,0x09,0x0a,0x0b,
	0x10,0x11,0x12,0x13,
	0x18,0x19,0x1a,0x1b
};
*/

void gmc4wait(long waittime)
{
	while(waittime-- >0){
	}
}

void gmc4init()
{
	GMC4_KEYDDR |= (GMC4_KEYMASK << GMC4_KEY);
	GMC4_ENDDR  |= GMC4_EN;

	GMC4_FLAG = 0;
}

void enable()
{
	GMC4_ENPORT &= ~GMC4_EN;
	gmc4wait(GMC4_WAIT);
	GMC4_ENPORT |= GMC4_EN;
	gmc4wait(GMC4_WAIT);
}

void gmc4send1KEY(unsigned char KEY)
{
	char OUTKEY;
//	OUTKEY = GMC4_KEYMAP[KEY];
	OUTKEY = (KEY & 0xf);
	GMC4_KEYPORT &= ~(GMC4_KEYMASK << GMC4_KEY);
	GMC4_KEYPORT |= ((GMC4_KEYMASK & OUTKEY)<< GMC4_KEY);
	enable();
	GMC4_FLAG = 1;
}

void gmc4send1fkey(unsigned char KEY)
{
	GMC4_KEYPORT &= ~(GMC4_KEYMASK << GMC4_KEY);
	GMC4_KEYPORT |= ((GMC4_KEYMASK & KEY)<< GMC4_KEY);
	enable();
	GMC4_FLAG = 0;
}

void gmc4sendkey(char skey) 
{
	unsigned char KEY;

	if(skey >= '0' && skey <= '9'){
		KEY = skey -'0';
		gmc4send1KEY(KEY);
	} else if(skey >= 'A' && skey <= 'F'){
		KEY = skey - 'A' + 10;
		gmc4send1KEY(KEY);
	} else if(skey >= 'a' && skey <= 'f'){
		KEY = skey - 'a' + 10;
		gmc4send1KEY(KEY);
	} else if(skey == ':' || skey == 'S' || skey == 's'){
		gmc4send1fkey(GMC4_ADRSET);
	} else if(skey == 'I' || skey == 'i'){
		gmc4send1fkey(GMC4_INCR);
	} else if(skey == ' ' || skey == 0x0d ){
		if(GMC4_FLAG == 1){
			gmc4send1fkey(GMC4_INCR);
		}
	} else if(skey == '!' || skey == 'G' || skey == 'g'){
		gmc4send1fkey(GMC4_RUN);
	} else if(skey == '/' || skey == 'R' || skey == 'r'){
		gmc4send1fkey(GMC4_RESET);
	}
}

