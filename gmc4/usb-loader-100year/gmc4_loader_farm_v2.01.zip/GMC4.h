// GMC4.h
// GMC-4 AutoKeyIn Module for Type A 
// 2009/08/03
// by maris

void gmc4wait(long waittime);

void gmc4send1hkey(unsigned char hkey);

void gmc4send1fkey(unsigned char fkey);

void gmc4sendkey(char skey) ;

void gmc4init();
