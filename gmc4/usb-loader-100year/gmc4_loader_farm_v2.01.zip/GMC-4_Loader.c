// GMC-4 Loader.c
// GMC-4 Loader Ver2.01
// 2009/08/03
// by maris

#include <avr/io.h>
#include <avr/interrupt.h>
#include "GMC4.h"

#define BUFFSIZE 32
#define BUFFMASK 0x1f

#define RTS_PORT PORTD
#define RTS_BIT  2

char init_msg[] = "GMC-4 Loader Ver. 2.01";
char buff[BUFFSIZE];

unsigned char	rxcnt;	//Receive count
unsigned char	rxptr;	//Receive pointer
unsigned char	rdptr;	//Read pointer

void port_init(void)
{
	DDRA = 0x03;
	PORTA = 0x03;

	DDRB  = 0xFF;
	PORTB = 0xFF;

	DDRD  = 0x7F;
	PORTD = 0x7F;
}

//UART initialize
void uart_init(void)
{
	UCSRB = 0x00; //disable while setting baud rate
	UCSRA = 0x00;
	UCSRC = 0x06;
	UBRRL = 25; //set baud rate lo
	UBRRH = 0x00; //set baud rate hi
	UCSRB = 0x98;

	RTS_PORT &= ~(1 << RTS_BIT);
}

//call this routine to initialize all peripherals
void init_devices(void)
{
	cli(); 
	port_init();
	uart_init();

	MCUCR = 0x00;
	TIMSK = 0x00; //timer 0 interrupt sources
	PCMSK = 0x00; //pin change mask 0 

	rxcnt = 0;
	rxptr = 0;
	rdptr = 0;

	sei();
}


ISR(USART_RX_vect)		//Rx Complete
{
	buff[rxptr++ & BUFFMASK] = UDR;
	rxcnt++;
	if (rxcnt > 26){
		RTS_PORT |= (1 << RTS_BIT);
	}
}

//ISR(USART_TX_vect)		//Tx Complete
//{
//}

//ISR(USART_UDRE_vect)	//Data Register Empty
//{
//}


void USART_Tx(char tx_data)  
  {
   while ( !(UCSRA & (1<<UDRE)) )
      ;
   UDR = tx_data;
  }

unsigned char USART_Rx(void)
  {
	unsigned char ret;

	while (rxptr == rdptr);
			
	ret = buff[rdptr++ & BUFFMASK];
	rxcnt--;	
	if (rxcnt < 10){
		RTS_PORT &= ~(1 << RTS_BIT);
	}
	return ret;
  }
  
void STRING_OUT(char *msg_string)
  {
    unsigned char i;
	  i=0;
     while (msg_string[i] !='\0')
	   {
	   USART_Tx(msg_string[i]);
	    i++;
       }
  } 


int main(void)
{
 unsigned char command;
	init_devices();

	USART_Tx(0x0d);
	USART_Tx(0x0a);
	USART_Tx(' ');
	STRING_OUT(init_msg);
	USART_Tx(0x0d);
	USART_Tx(0x0a);
	gmc4init();

	gmc4wait(1000000);
	while(1)
	{
		command = USART_Rx();
		switch(command){
		case 0x0d:
			USART_Tx(command);
			USART_Tx(0x0a);
			break;
		case '/':
			USART_Tx(0x0d);
			USART_Tx(0x0a);
			USART_Tx(command);
			break;
		case '!':
			USART_Tx(command);
			USART_Tx(0x0d);
			USART_Tx(0x0a);
			break;
		default:
			USART_Tx(command);
			break;
		}
		gmc4sendkey(command);
	}
}

