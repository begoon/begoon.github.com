#include "sys.h"
#include "libmy/libmy.h"
#include "irq_arm.h"
#include "state.h"


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
EWRAM_CODE void SysInit(void)
{
	LibMyInit();
	StateInit();

	IrqInit();
}
//---------------------------------------------------------------------------
EWRAM_CODE void SysExec(void)
{
	for(;;)
	{
		SystemCall(5);

		LibMyExec();
		StateExec();
	}
}
