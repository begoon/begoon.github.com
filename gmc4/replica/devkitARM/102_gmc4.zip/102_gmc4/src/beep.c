#include "beep.h"
#include "libmy/mml.h"


//---------------------------------------------------------------------------
ST_BEEP Beep;


//---------------------------------------------------------------------------
EWRAM_CODE void BeepInit(void)
{
	_Memset(&Beep, 0x00, sizeof(ST_BEEP));

	BeepSetOn();
}
//---------------------------------------------------------------------------
EWRAM_CODE void BeepExec(void)
{
	// EMPTY
}
//---------------------------------------------------------------------------
EWRAM_CODE void BeepSetOn(void)
{
	Beep.isOn = TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void BeepSetOff(void)
{
	Beep.isOn = FALSE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void BeepPlay(char* pStr)
{
	if(Beep.isOn == FALSE)
	{
		return;
	}

	MmlInitCh(0, pStr);
	MmlPlay();
}
//---------------------------------------------------------------------------
EWRAM_CODE void BeepPlayPush(void)
{
	BeepPlay("O5 L64 E");
}
//---------------------------------------------------------------------------
// E7
EWRAM_CODE void BeepPlayEnd(void)
{
	BeepPlay("T180 O6 L32 G A G A B");
}
//---------------------------------------------------------------------------
// E8
EWRAM_CODE void BeepPlayErr(void)
{
	BeepPlay("T180 O6 L32 CDCDCD");
}
//---------------------------------------------------------------------------
// E9
EWRAM_CODE void BeepPlayPiShort(void)
{
	BeepPlay("O6 L32 D RRRRR");
}
//---------------------------------------------------------------------------
// EA
EWRAM_CODE void BeepPlayPiLong(void)
{
	BeepPlay("O6 L16 D");
}
//---------------------------------------------------------------------------
// EB
EWRAM_CODE void BeepPlayTone(u8 num)
{
	_ASSERT(num <= 0x0f);


	if(num == 0 || num == 0x0f)
	{
		return;
	}

	switch(num)
	{
	case 0x01: BeepPlay("O3 L16 F"); break;
	case 0x02: BeepPlay("O3 L16 G"); break;

	case 0x03: BeepPlay("O4 L16 C"); break;
	case 0x04: BeepPlay("O4 L16 D"); break;
	case 0x05: BeepPlay("O4 L16 E"); break;
	case 0x06: BeepPlay("O4 L16 F"); break;
	case 0x07: BeepPlay("O4 L16 G"); break;
	case 0x08: BeepPlay("O4 L16 A"); break;
	case 0x09: BeepPlay("O4 L16 B"); break;

	case 0x0a: BeepPlay("O5 L16 C"); break;
	case 0x0b: BeepPlay("O5 L16 D"); break;
	case 0x0c: BeepPlay("O5 L16 E"); break;
	case 0x0d: BeepPlay("O5 L16 F"); break;
	case 0x0e: BeepPlay("O5 L16 G"); break;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE bool BeepIsEnd(void)
{
	return MmlIsEnd();
}
