#include "bg.h"
#include "bios_arm.h"
#include "../res.h"


//---------------------------------------------------------------------------
ST_BG Bg[BG_MAX_CNT];


//---------------------------------------------------------------------------
EWRAM_CODE void BgInit(void)
{
	_Memset((u8*)&Bg, 0x00, sizeof(ST_BG) * BG_MAX_CNT);

	BiosExecFixClear((u32*)VRAM, 0x10000);
	BiosExecFixClear(BG_PALETTE, 0x400);


	// bg0 None
	// bg1 None
	// bg2 ASCII
	// bg3 GMC or ���j�^

	BgSetOpt(2, 2, 24, 0);
	BgSetOpt(3, 0, 25, 0);

	BgSetDatAscii();
	BgDrawCap();
	BgExec();

//	REG_BG0CNT = (BG_SIZE_3 | BG_16_COLOR | TILE_BASE(Bg[0].tile) | MAP_BASE(Bg[0].map) | 0);
//	REG_BG1CNT = (BG_SIZE_3 | BG_16_COLOR | TILE_BASE(Bg[1].tile) | MAP_BASE(Bg[1].map) | 0);
	REG_BG2CNT = (BG_SIZE_0 | BG_16_COLOR | TILE_BASE(Bg[2].tile) | MAP_BASE(Bg[2].map) | 0);
	REG_BG3CNT = (BG_SIZE_0 | BG_16_COLOR | TILE_BASE(Bg[3].tile) | MAP_BASE(Bg[3].map) | 0);

	REG_DISPCNT = (MODE_0 | BG2_ON | BG3_ON);
}
//---------------------------------------------------------------------------
EWRAM_CODE void BgSetOpt(u16 no, u16 tile, u16 map, u16 pal)
{
	_ASSERT(no <= BG_MAX_CNT);


	Bg[no].tile = tile;
	Bg[no].map  = map;
	Bg[no].pal  = pal;

	Bg[no].pBaseTile = TILE_BASE_ADR(tile);
	Bg[no].pBaseMap  = MAP_BASE_ADR(map);
	Bg[no].pBasePal  = BG_PALETTE + (pal * 16);

	Bg[no].isUse = TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void BgSetDat(u16 no, u16* pTile, u32 tileSize, u16* pPal, u32 palSize)
{
	BiosExec(pTile, Bg[no].pBaseTile, tileSize);
	BiosExec(pPal, Bg[no].pBasePal, palSize);
}
//---------------------------------------------------------------------------
EWRAM_CODE void BgSetDatAscii(void)
{
	BgSetDat(2, (u16*)bg_asciiTiles, bg_asciiTilesLen, (u16*)bg_asciiPal, bg_asciiPalLen);
}
//---------------------------------------------------------------------------
EWRAM_CODE void BgSetDatGmc(void)
{
	BgSetDat(3, (u16*)bg_gmcTiles, bg_gmcTilesLen, (u16*)bg_gmcPal, bg_gmcPalLen);
}
//---------------------------------------------------------------------------
EWRAM_CODE void BgSetDatMonitor(void)
{
	BgSetDat(3, (u16*)bg_monitorTiles, bg_monitorTilesLen, (u16*)bg_monitorPal, bg_monitorPalLen);
}
//---------------------------------------------------------------------------
IWRAM_CODE void BgDrawChr(u16 x, u16 y, u16 chr)
{
	Bg[2].mapBuf[x + y * 32] = chr;
	Bg[2].isDraw = TRUE;
}
//---------------------------------------------------------------------------
IWRAM_CODE void BgDrawStr(u16 x, u16 y, char* pStr)
{
	while(*pStr != NULL)
	{
		BgDrawChr(x++, y, *pStr++ - ' ');
	}
}
//---------------------------------------------------------------------------
IWRAM_CODE void BgDrawVal(u16 x, u16 y, char* pFormat, u16 val)
{
	char buf[32];

	_Sprintf(buf, pFormat, val);
	BgDrawStr(x, y, buf);
}
//---------------------------------------------------------------------------
IWRAM_CODE void BgDrawCap(void)
{
	u16 cnt = 0;
	u16 x, y;

	for(y=0; y<20; y++)
	{
		for(x=0; x<32; x++)
		{
			Bg[3].mapBuf[x + y * 32] = cnt++;
		}
	}

	Bg[3].isDraw = TRUE;
}
//---------------------------------------------------------------------------
IWRAM_CODE void BgDrawCls(void)
{
	u16 x, y;

	for(y=0; y<20; y++)
	{
		for(x=0; x<32; x++)
		{
			Bg[2].mapBuf[x + y * 32] = 0;
		}
	}

	Bg[2].isDraw = TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void BgExec(void)
{
	s16 i;

	for(i=0; i<BG_MAX_CNT; i++)
	{
		if(Bg[i].isDraw == FALSE)
		{
			continue;
		}
		Bg[i].isDraw = FALSE;


		BiosExec(Bg[i].mapBuf, Bg[i].pBaseMap, BG_MAX_MAP_BUF_SIZE);
	}
}
