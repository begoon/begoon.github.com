#include "mml.h"

//---------------------------------------------------------------------------
// ���K�Ǝ����̕ϊ��\�i����0�ɂ̓p�[�J�b�V�����p�̃f�[�^�������Ă��܂��j
u16 MmlFleqTable[14][10] = {
//   0  1  2     3     4     5     6     7     8  9
	{0, 0, 0,    0,  986, 1517, 1783, 1915, 1982, 0},	// B
	{7, 0, 0,   44, 1046, 1546, 1798, 1923, 1985, 0},	// C   
	{7, 0, 0,  156, 1102, 1575, 1812, 1930, 1988, 0},	// CS
	{6, 0, 0,  262, 1155, 1602, 1825, 1936, 1992, 0},	// D
	{6, 0, 0,  363, 1205, 1627, 1837, 1943, 1995, 0},	// DS
	{5, 0, 0,  457, 1253, 1650, 1849, 1949, 1998, 0},	// E
	{4, 0, 0,  547, 1297, 1673, 1860, 1954, 2001, 0},	// F
	{4, 0, 0,  631, 1339, 1694, 1871, 1959, 2004, 0},	// FS
	{3, 0, 0,  710, 1379, 1714, 1881, 1964, 2006, 0},	// G
	{3, 0, 0,  786, 1417, 1732, 1890, 1969, 2009, 0},	// GS
	{2, 0, 0,  854, 1452, 1750, 1899, 1974, 2011, 0},	// A
	{2, 0, 0,  923, 1486, 1767, 1907, 1978, 2013, 0},	// AS
	{1, 0, 0,  986, 1517, 1783, 1915, 1982, 2015, 0},	// B
	{0, 0, 0, 1046, 1546, 1798, 1923, 1985,    0, 0},	// C
};


//---------------------------------------------------------------------------
ST_MML Mml[MML_MAX_CNT];


//---------------------------------------------------------------------------
EWRAM_CODE void MmlInit(void)
{
	_Memset((u8*)&Mml, 0x00, sizeof(ST_MML) * MML_MAX_CNT);


	REG_SOUNDCNT_X = ALL_SOUND_ENABLE;

	REG_SOUNDCNT_L = DMG_LEFT_VOLUME(2) | DMG_RIGHT_VOLUME(2) |
	                 SOUND1_LEFT_OUTPUT | SOUND1_RIGHT_OUTPUT |
	                 SOUND2_LEFT_OUTPUT | SOUND2_RIGHT_OUTPUT |
	                 SOUND3_LEFT_OUTPUT | SOUND3_RIGHT_OUTPUT |
	                 SOUND4_LEFT_OUTPUT | SOUND4_RIGHT_OUTPUT;

	REG_SOUNDCNT_H = SOUND_OUTPUT_RATIO(2);
}
//---------------------------------------------------------------------------
IWRAM_CODE void MmlInitCh(u16 ch, char* pStr)
{
	_ASSERT(ch < MML_MAX_CNT);


	ST_MML* p = &Mml[ch];

	p->pStr        = pStr;
	p->pCur        = NULL;
	p->pPrev       = NULL;
	p->tempo       = MML_TEMPO_MAGIC / 120;
	p->len         = 4;
	p->lenOnce     = 0;
	p->lenCtdn     = 0;
	p->octave      = (ch != 3) ? 4 : 0;
	p->fleq        = 0;
	p->isRelativeX = FALSE;
	p->isRepeat    = FALSE;
	p->isPlay      = FALSE;
	p->isErr       = FALSE;
	p->volume      = 7;
	p->tone        = 3;
	p->envelopStep = 7;
	p->sweepDir    = 0;
	p->sweepShift  = 0;
	p->sweepTime   = 0;
}
//---------------------------------------------------------------------------
IWRAM_CODE void MmlPlay(void)
{
	s16 i;

	for(i=0; i<MML_MAX_CNT; i++)
	{
		if(Mml[i].pStr != NULL)
		{
			Mml[i].pCur   = Mml[i].pStr;
			Mml[i].isPlay = TRUE;
		}
	}
}
//---------------------------------------------------------------------------
//�Z�`�g�Đ�+�X�C�[�v+�G���x���[�v
IWRAM_CODE void MmlPlayCh1(void)
{
	ST_MML* p = &Mml[0];

	if(p->fleq == 0)
	{
		REG_SOUND1CNT_H = 0;
		return;
	}


	REG_SOUND1CNT_L = SOUND1_SWEEP_SHIFT(p->sweepShift)   |
	                  SOUND1_SWEEP_DIR(p->sweepDir)       |
	                  SOUND1_SWEEP_TIME(p->sweepTime);

	REG_SOUND1CNT_H = SOUND1_LENGTH(0)                    |
	                  SOUND1_DUTY_CYCLE(p->tone)          |
	                  SOUND1_ENVELOP_STEP(p->envelopStep) |
	                  SOUND1_ENVELOP_DEC                  |
	                  SOUND1_ENVELOP_VALUE(p->volume);

	REG_SOUND1CNT_X = SOUND1_FREQ(p->fleq) | SOUND1_CONTINUE | SOUND1_RESET;
}
//---------------------------------------------------------------------------
//�Z�`�g�Đ�+�G���x���[�v
IWRAM_CODE void MmlPlayCh2(void)
{
	ST_MML* p = &Mml[1];

	if(p->fleq == 0)
	{
		REG_SOUND2CNT_H = 0;
		return;
	}


	REG_SOUND2CNT_L = SOUND2_LENGTH(0)                    |
	                  SOUND2_DUTY_CYCLE(p->tone)          |
	                  SOUND2_ENVELOP_STEP(p->envelopStep) |
	                  SOUND2_ENVELOP_DEC                  |
	                  SOUND2_ENVELOP_VALUE(p->volume);

	REG_SOUND2CNT_H = SOUND2_FREQ(p->fleq) | SOUND2_CONTINUE | SOUND2_RESET;
}
//---------------------------------------------------------------------------
//�z���C�g�m�C�Y�Đ�+�G���x���[�v
IWRAM_CODE void MmlPlayCh4(void)
{
	ST_MML* p = &Mml[3];

	if(p->fleq == 0)
	{
		REG_SOUND4CNT_L = 0;
		return;
	}


	REG_SOUND4CNT_L = SOUND4_LENGTH(0)                    |
	                  SOUND4_ENVELOP_STEP(p->envelopStep) |
	                  SOUND4_ENVELOP_DEC                  |
	                  SOUND4_ENVELOP_VALUE(p->volume);

	REG_SOUND4CNT_H = SOUND4_STAGE_FREQ(6 - p->tone * 2)  |
	                  SOUND4_DIVIDE_FREQ(p->fleq)         |
	                  SOUND4_CONTINUE                     |
	                  SOUND4_RESET                        |
	                  SOUND4_STAGE_15;
}
//---------------------------------------------------------------------------
IWRAM_CODE void MmlStop(void)
{
	s16 i;

	for(i=0; i<MML_MAX_CNT; i++)
	{
		Mml[i].isPlay = FALSE;
		Mml[i].fleq = 0;
	}

	MmlPlayCh1();
	MmlPlayCh2();
	MmlPlayCh4();
}
//---------------------------------------------------------------------------
IWRAM_CODE u16 MmlGetFleq(u16 ch)
{
	ST_MML* p = &Mml[ch];

	u16 tok;
	u16 num;
	s16 i;

st:
    tok = MmlGetToken(ch);


	switch(tok)
	{
	// error
	case TOKEN_ERR:
		return MML_FLEQ_ERR;

	// end
	case TOKEN_ED:
		return MML_FLEQ_END;

	// R
	case TOKEN_REST:
		return MML_FLEQ_REST;

	// X
	case TOKEN_RELATIVE_X:
		p->isRelativeX = TRUE;
		goto st;

	// >
	case TOKEN_OCTAVE_UP:
		if(p->isRelativeX == FALSE)
		{
			MmlUpOctave(ch);
		}
		else
		{
			MmlDownOctave(ch);
		}
		goto st;

	// <
	case TOKEN_OCTAVE_DOWN:
		if(p->isRelativeX == FALSE)
		{
			MmlDownOctave(ch);
		}
		else
		{
			MmlUpOctave(ch);
		}
		goto st;

	// On
	case TOKEN_OCTAVE:
		if(MmlIsNumber(*p->pCur) == FALSE || MmlIsOctave(*p->pCur - '0') == FALSE)
		{
			return MML_FLEQ_ERR;
		}
		p->octave = *p->pCur++ - '0';
		goto st;

	// @n
	case TOKEN_TONE:
		if(MmlIsNumber(*p->pCur) == FALSE || MmlIsTone(*p->pCur - '0') == FALSE)
		{
			return MML_FLEQ_ERR;
		}
		p->tone = *p->pCur++ - '0';
		goto st;

	// Qn
	case TOKEN_ENVELOP_STEP:
		if(MmlIsNumber(*p->pCur) == FALSE || MmlIsEnvelopStep(*p->pCur - '0') == FALSE)
		{
			return MML_FLEQ_ERR;
		}
		p->envelopStep = *p->pCur++ - '0';
		goto st;

	// Sn,m
	case TOKEN_SWEEP:
		// n
		if(MmlIsNumber(*p->pCur) == FALSE || MmlIsSweepTime(*p->pCur - '0') == FALSE)
		{
			return MML_FLEQ_ERR;
		}
		p->sweepTime = *p->pCur++ - '0';

		// ,
		if(*p->pCur != ',')
		{
			return MML_FLEQ_ERR;
		}
		p->pCur++;

		// -
		if(*p->pCur == '-')
		{
			p->sweepDir = 0;
			p->pCur++;
		}
		else
		{
			p->sweepDir = 1;
		}

		// m
		if(MmlIsNumber(*p->pCur) == FALSE || MmlIsSweepShift(*p->pCur - '0') == FALSE)
		{
			return MML_FLEQ_ERR;
		}
		p->sweepShift = *p->pCur++ - '0';
		goto st;

	// Lnn
	case TOKEN_LEN:
		num = 0;

		// n(2)
		for(i=0; i<2; i++)
		{
			if(MmlIsNumber(*p->pCur) == TRUE)
			{
				num = (num * 10) + (*p->pCur++ - '0');
			}
			else
			{
				break;
			}
		}

		if(MmlIsLen(num) == FALSE)
		{
			return MML_FLEQ_ERR;
		}

		p->len = Div(p->tempo, num);
		goto st;

	// Vnn
	case TOKEN_VOLUME:
		num = 0;

		// n(2)
		for(i=0; i<2; i++)
		{
			if(MmlIsNumber(*p->pCur) == TRUE)
			{
				num = (num * 10) + (*p->pCur++ - '0');
			}
			else
			{
				break;
			}
		}

		if(MmlIsVolume(num) == FALSE)
		{
			return MML_FLEQ_ERR;
		}

		p->volume = num;
		goto st;

	// Tnnn
	case TOKEN_TEMPO:
		num = 0;

		// n(3)
		for(i=0; i<3; i++)
		{
			if(MmlIsNumber(*p->pCur) == TRUE)
			{
				num = (num * 10) + (*p->pCur++ - '0');
			}
			else
			{
				break;
			}
		}

		if( MmlIsTempo(num) == FALSE )
		{
			return MML_FLEQ_ERR;
		}

		p->tempo = num;
		goto st;

	// ����
	case TOKEN_C:
	case TOKEN_D:
	case TOKEN_E:
	case TOKEN_F:
	case TOKEN_G:
	case TOKEN_A:
	case TOKEN_B:

		// �����̂��� # + -
		if(*p->pCur == TOKEN_SHARP)
		{
			tok++;
			p->pCur++;
		}
		else if(*p->pCur == TOKEN_FLAT)
		{
			tok--;
			p->pCur++;
		}

		// �������`�F�b�N�����܂�
		if(MmlIsNumber(*p->pCur) == FALSE)
		{
			return MmlFleqTable[tok][p->octave];
		}
		num = *p->pCur++ - '0';

		// ����ɐ������`�F�b�N�����܂�

		if(MmlIsNumber(*p->pCur) == TRUE)
		{
			num = (num * 10) + (*p->pCur++ - '0');
		}

		if(MmlIsOctave(num) == FALSE)
		{
			return MML_FLEQ_ERR;
		}
		p->lenOnce = Div(p->tempo, num);


		// �s���I�h�����邩�`�F�b�N�����܂��i�Q��m�F�j
		for(i=0; i<2; i++)
		{
			if(*p->pCur == '.')
			{
				p->lenOnce += Div(p->tempo, Div(num, ((i*2)+2)) );
				p->pCur++;
			}
			else
			{
				break;
			}
		}

		return MmlFleqTable[tok][p->octave];
	}

	return MML_FLEQ_ERR;
}
//---------------------------------------------------------------------------
IWRAM_CODE u16 MmlGetToken(u16 ch)
{
	ST_MML* p = &Mml[ch];

st:
	p->pPrev = p->pCur;

	switch(*p->pCur++)
	{
	case ' ':
		goto st;

	case 'R':
	case 'r':
		return TOKEN_REST;

	case 'C':
	case 'c':
		return TOKEN_C;

	case 'D':
	case 'd':
		return TOKEN_D;

	case 'E':
	case 'e':
		return TOKEN_E;

	case 'F':
	case 'f':
		return TOKEN_F;

	case 'G':
	case 'g':
		return TOKEN_G;

	case 'A':
	case 'a':
		return TOKEN_A;

	case 'B':
	case 'b':
		return TOKEN_B;

	case 'O':
	case 'o':
		return TOKEN_OCTAVE;

	case '>':
		return TOKEN_OCTAVE_UP;

	case '<':
		return TOKEN_OCTAVE_DOWN;

	case 'X':
	case 'x':
		return TOKEN_RELATIVE_X;

	case 'L':
	case 'l':
		return TOKEN_LEN;

	case '.':
		return TOKEN_PERIOD;

	case 'T':
	case 't':
		return TOKEN_TEMPO;

	case '#':
	case '+':
		return TOKEN_SHARP;

	case '-':
		return TOKEN_FLAT;

	case 'V':
	case 'v':
		return TOKEN_VOLUME;

	case '@':
		return TOKEN_TONE;

	case 'Q':
	case 'q':
		return TOKEN_ENVELOP_STEP;

	case 'S':
	case 's':
		return TOKEN_SWEEP;

	case ',':
		return TOKEN_CANMA;

	case '\0':
		return TOKEN_ED;
    }

	return TOKEN_ERR;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsOctave(s16 num)
{
	return (num >= 3) && (num <= 8) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsTone(s16 num)
{
	return (num >= 0) && (num <= 3) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsEnvelopStep(s16 num)
{
	return (num >= 0) && (num <= 7) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsSweepTime(s16 num)
{
	return (num >= 0) && (num <= 7) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsSweepShift(s16 num)
{
	return (num >= 0) && (num <= 7) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsLen(s16 num)
{
	return (num >= 1) && (num <= 64) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsVolume(s16 num)
{
	return (num >= 0) && (num <= 15) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsTempo(s16 num)
{
	return (num >= 1) && (num <= 255) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsNumber(char chr)
{
	return ( (chr >= '0') && (chr <= '9') ) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool MmlIsEnd()
{
	bool ret = FALSE;

	ret |= Mml[0].isPlay;
	ret |= Mml[1].isPlay;
	ret |= Mml[3].isPlay;

	return (ret == FALSE) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
IWRAM_CODE void MmlDownOctave(u16 ch)
{
	if(MmlIsOctave(Mml[ch].octave - 1) == TRUE)
	{
		Mml[ch].octave--;
	}
}
//---------------------------------------------------------------------------
IWRAM_CODE void MmlUpOctave(u16 ch)
{
	if(MmlIsOctave(Mml[ch].octave + 1) == TRUE)
	{
		Mml[ch].octave++;
	}
}
//---------------------------------------------------------------------------
IWRAM_CODE void MmlIntr(void)
{
	s16 i;

	for(i=0; i<MML_MAX_CNT; i++)
	{
		MmlIntrSub(i);
	}
}
//---------------------------------------------------------------------------
IWRAM_CODE void MmlIntrSub(u16 ch)
{
	ST_MML* p = &Mml[ch];

	if(p->isPlay == FALSE)
	{
		return;
	}

	if(p->lenCtdn != 0)
	{
		p->lenCtdn--;
		return;
	}

	p->fleq = MmlGetFleq(ch);

	if(p->fleq == MML_FLEQ_ERR)
	{
		p->isErr = TRUE;

		MmlStop();
		return;
	}

	if(p->fleq == MML_FLEQ_END && p->isRepeat == FALSE)
	{
		MmlStop();
		return;
	}


	if(p->lenOnce != 0)
	{
		p->lenCtdn = p->lenOnce;
		p->lenOnce = 0;
	}
	else
	{
		p->lenCtdn = p->len;
	}

	switch(ch)
	{
	case 0:
		MmlPlayCh1();
		break;
	case 1:
		MmlPlayCh2();
		break;
	case 3:
		MmlPlayCh4();
		break;
	}
}
