#include "libmy.h"

// #include "ad_arm.h"
// #include "adrv.h"
#include "bg.h"
#include "bios_arm.h"
// #include "debug.h"
// #include "dma_arm.h"
// #include "fade.h"
#include "gbfs.h"
#include "intr_arm.h"
#include "key.h"
#include "lex.h"
// #include "mem.h"
#include "mml.h"
// #include "mode3.h"
// #include "mt.h"
// #include "snd.h"
#include "spr.h"
#include "sram.h"


//---------------------------------------------------------------------------
EWRAM_CODE void LibMyInit(void)
{
	REG_WSCNT = 0x4317;


//	MtInit();
//	MemInit();
	SramInit();
	GbfsInit();

	BgInit();
//	Mode3Init();

	SprInit();
	KeyInit();
//	DmaInit();

	BiosInit();
	LexInit();
//	FadeInit();
//	DebugInit();

//	AdInit();
//	SndInit();
//	AdrvInit();
	MmlInit();

	IntrInit();
	IntrStart();
}
//---------------------------------------------------------------------------
IWRAM_CODE void LibMyExec(void)
{
//	DmaTransfer();

//	TODO ����ADraw�n��Exec�Ƀ��l�[�����邱��

//	FadeDraw();
//	Mode3Draw();
//	DebugDraw();

	BgExec();
	SprExec();
	KeyExec();
//	DebugExec();
}
