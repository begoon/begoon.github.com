#include "spr.h"
#include "bios_arm.h"
#include "../res.h"

// Mode3     BITMAP_OBJ_BASE_ADR
// Mode3�ȊO OBJ_BASE_ADR


//---------------------------------------------------------------------------
ST_SPR Spr;


//---------------------------------------------------------------------------
EWRAM_CODE void SprInit(void)
{
	BiosExecFixClear(&Spr, sizeof(ST_SPR));
	BiosExecFixClear(OBJ_BASE_ADR, 1024 * 32);


	SprSetDatItem();
	SprSetChrItem();

	REG_DISPCNT |= (OBJ_ON | OBJ_2D_MAP);
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprSetDat(u16* pTile, u32 tileSize, u16* pPal, u32 palSize)
{
	BiosExec(pTile, OBJ_BASE_ADR, tileSize);
	BiosExec(pPal, OBJ_COLORS, palSize);
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprSetDatItem(void)
{
	SprSetDat((u16*)spr_itemTiles, spr_itemTilesLen, (u16*)spr_itemPal, spr_itemPalLen);
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprSetChr(u16 no, u16 x, u16 y, u16 tile, u16 shape, u16 size)
{
	Spr.attr[no].d0 = (y & 0x00ff) | ATTR0_COLOR_16 | ATTR0_DISABLED | shape;
	Spr.attr[no].d1 = (x & 0x01ff) | size;
	Spr.attr[no].d2 = tile | ATTR2_PRIORITY(0);

	Spr.isDraw = TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprSetChrItem(void)
{
	// 0     �J�[�\��(32x32)
	// 1�`7  2LED(8x16)
	// 8�`14 7LED(���_: 8x16�A�c�_: 32x32)

	SprSetChr( 0,  72, 116,  5, ATTR0_SQUARE, ATTR1_SIZE_32);

	SprSetChr( 1, 212,  16,  3, ATTR0_WIDE, ATTR1_SIZE_8);		// 0 bit
	SprSetChr( 2, 180,  16,  3, ATTR0_WIDE, ATTR1_SIZE_8);
	SprSetChr( 3, 148,  16,  3, ATTR0_WIDE, ATTR1_SIZE_8);
	SprSetChr( 4, 116,  16,  3, ATTR0_WIDE, ATTR1_SIZE_8);
	SprSetChr( 5,  84,  16,  3, ATTR0_WIDE, ATTR1_SIZE_8);
	SprSetChr( 6,  52,  16,  3, ATTR0_WIDE, ATTR1_SIZE_8);
	SprSetChr( 7,  20,  16,  3, ATTR0_WIDE, ATTR1_SIZE_8);		// 7 bit

	SprSetChr( 8,  28,  80, 13, ATTR0_WIDE, ATTR1_SIZE_8);		// a
	SprSetChr( 9,  42,  81, 19, ATTR0_TALL, ATTR1_SIZE_32);		// b
	SprSetChr(10,  41,  99, 21, ATTR0_TALL, ATTR1_SIZE_32);		// c
	SprSetChr(11,  26, 114, 17, ATTR0_WIDE, ATTR1_SIZE_8);		// d
	SprSetChr(12,  24,  99, 23, ATTR0_TALL, ATTR1_SIZE_32);		// e
	SprSetChr(13,  25,  81, 25, ATTR0_TALL, ATTR1_SIZE_32);		// f
	SprSetChr(14,  27,  97, 15, ATTR0_WIDE, ATTR1_SIZE_8);		// g
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprSetView(u16 no)
{
	Spr.attr[no].d0 &= ~ATTR0_DISABLED;

	Spr.isDraw = TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprSetHide(u16 no)
{
	Spr.attr[no].d0 |= ATTR0_DISABLED;

	Spr.isDraw = TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprSetBinary(u16 val)
{
	u16 mask = 0x01;
	s16 i;

	for(i=0; i<7; i++)
	{
		if(val & mask)
		{
			SprSetView(1 + i);
		}
		else
		{
			SprSetHide(1 + i);
		}

		mask <<= 1;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprSetHex(u16 val)
{
	_ASSERT(val <= 0x0F);

	const u8 pat[] = {
		0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07,
		0x7F, 0x67, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71,
	};

	u16 work = pat[val];
	u16 mask = 0x01;
	s16 i;

	for(i=0; i<7; i++)
	{
		if(work & mask)
		{
			SprSetView(8 + i);
		}
		else
		{
			SprSetHide(8 + i);
		}

		mask <<= 1;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprSetMove(u16 no, u16 x, u16 y)
{
	Spr.attr[no].d0 &= 0xff00;
	Spr.attr[no].d1 &= 0xfe00;

	Spr.attr[no].d0 |= (y & 0x00ff);
	Spr.attr[no].d1 |= (x & 0x01ff);

	Spr.isDraw = TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprExec(void)
{
	if(Spr.isDraw == TRUE)
	{
		BiosExec(Spr.attr, OAM, sizeof(ST_SPR_ATTR) * SPR_MAX_ATTR_CNT);
		Spr.isDraw = FALSE;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprCursorMove(u16 x, u16 y)
{
	SprSetMove(0, x, y);
	SprSetView(0);
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprCursorChgShape(void)
{
	u16 num = Spr.attr[0].d2 & 0x03ff;

	if(RES_SPR_CURSOR_PUSH_NUM == num)
	{
		Spr.attr[0].d2 = RES_SPR_CURSOR_NUM;
	}
	else
	{
		Spr.attr[0].d2 = RES_SPR_CURSOR_PUSH_NUM;
	}

	Spr.isDraw = TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE bool SprCursorIsPush(void)
{
	u16 num = Spr.attr[0].d2 & 0x03ff;

	return(num == RES_SPR_CURSOR_PUSH_NUM) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprCursorHide(void)
{
	SprSetHide(0);
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprLedHexHide(void)
{
	s16 i;

	for(i=0; i<7; i++)
	{
		SprSetHide(8+i);
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void SprLedBinaryHide(void)
{
	s16 i;

	for(i=0; i<7; i++)
	{
		SprSetHide(1+i);
	}
}
