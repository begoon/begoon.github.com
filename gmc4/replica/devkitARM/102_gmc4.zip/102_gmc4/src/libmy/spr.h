#ifndef __SPR_H__
#define __SPR_H__
#ifdef __cplusplus
extern "C" {
#endif


#include "../libgba/gba.h"

//---------------------------------------------------------------------------
#define SPR_MAX_ATTR_CNT					15


//---------------------------------------------------------------------------

typedef struct {
	u16 d0;
	u16 d1;
	u16 d2;
	u16 d3;
} __PACKED ST_SPR_ATTR;

typedef struct {
	bool isDraw;
	ST_SPR_ATTR attr[SPR_MAX_ATTR_CNT] ALIGN(4);

} ST_SPR;


//---------------------------------------------------------------------------
EWRAM_CODE void SprInit(void);

EWRAM_CODE void SprSetDat(u16* pTile, u32 tileSize, u16* pPal, u32 palSize);
EWRAM_CODE void SprSetDatItem(void);
EWRAM_CODE void SprSetChr(u16 no, u16 x, u16 y, u16 tile, u16 shape, u16 size);
EWRAM_CODE void SprSetChrItem(void);

EWRAM_CODE void SprSetView(u16 no);
EWRAM_CODE void SprSetHide(u16 no);

EWRAM_CODE void SprSetBinary(u16 val);
EWRAM_CODE void SprSetHex(u16 val);

EWRAM_CODE void SprSetMove(u16 no, u16 x, u16 y);
EWRAM_CODE void SprExec(void);

//----
EWRAM_CODE void SprCursorMove(u16 x, u16 y);
EWRAM_CODE void SprCursorChgShape(void);
EWRAM_CODE bool SprCursorIsPush(void);
EWRAM_CODE void SprCursorHide(void);

//----
EWRAM_CODE void SprLedHexHide(void);

//----
EWRAM_CODE void SprLedBinaryHide(void);


#ifdef __cplusplus
}
#endif
#endif
