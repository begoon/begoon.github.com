#ifndef __BG_H__
#define __BG_H__
#ifdef __cplusplus
extern "C" {
#endif

#include "../libgba/gba.h"

//---------------------------------------------------------------------------
#define BG_MAX_CNT				4
#define BG_MAX_MAP_BUF_CNT		(32 * 32)
#define BG_MAX_MAP_BUF_SIZE		(BG_MAX_MAP_BUF_CNT * 2)


//---------------------------------------------------------------------------

typedef struct {
	bool isUse;
	bool isDraw;
	u16  mapBuf[BG_MAX_MAP_BUF_CNT] ALIGN(4);

	u16  tile;
	u16  map;
	u16  pal;

	u16* pBaseTile;
	u16* pBaseMap;
	u16* pBasePal;

} ST_BG;


//---------------------------------------------------------------------------
EWRAM_CODE void BgInit(void);

EWRAM_CODE void BgSetOpt(u16 no, u16 tile, u16 map, u16 pal);
EWRAM_CODE void BgSetDat(u16 no, u16* pTile, u32 tileSize, u16* pPal, u32 palSize);
EWRAM_CODE void BgSetDatAscii(void);
EWRAM_CODE void BgSetDatGmc(void);
EWRAM_CODE void BgSetDatMonitor(void);

IWRAM_CODE void BgDrawChr(u16 x, u16 y, u16 chr);
IWRAM_CODE void BgDrawStr(u16 x, u16 y, char* pStr);
IWRAM_CODE void BgDrawVal(u16 x, u16 y, char* pFormat, u16 val);
IWRAM_CODE void BgDrawCap(void);
IWRAM_CODE void BgDrawCls(void);

EWRAM_CODE void BgExec(void);


#ifdef __cplusplus
}
#endif
#endif
