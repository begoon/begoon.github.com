#include "file.h"
#include "libmy/gbfs.h"
#include "libmy/lex.h"
#include "gmc.h"


//---------------------------------------------------------------------------
ST_FILE File;


//---------------------------------------------------------------------------
EWRAM_CODE void FileInit(void)
{
	_Memset(&File, 0x00, sizeof(ST_FILE));
}
//---------------------------------------------------------------------------
EWRAM_CODE void FileExec(void)
{
	// EMPTY
}
//---------------------------------------------------------------------------
EWRAM_CODE void  FileLoadIdx(void)
{
	char* p = GbfsGetSafePointer2(File.idx);
	u32 size = GbfsGetFileSize();

	LexSetCur(p, size);

	u16  adr = 0;
	u8   hex;
	char chr;

	for(;;)
	{
		chr = LexGetChr();

		if(chr == '\0')
		{
			break;
		}

		hex = FileGetHex(chr);
		GmcSetMem(adr++, hex);
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void FileNextIdx(void)
{
	if((File.idx + 1) >= GbfsGetArcCnt())
	{
		return;
	}

	File.idx++;
}
//---------------------------------------------------------------------------
EWRAM_CODE void FilePrevIdx(void)
{
	if(File.idx == 0)
	{
		return;
	}

	File.idx--;
}
//---------------------------------------------------------------------------
EWRAM_CODE char* FileGetName(void)
{
	if(GbfsGetArcCnt() == 0)
	{
		return "file not found";
	}

	GbfsGetSafePointer2(File.idx);

	return GbfsGetFileName();
}
//---------------------------------------------------------------------------
EWRAM_CODE u8 FileGetHex(char chr)
{
	chr = _Toupper(chr);

	if(chr >= '0' && chr <= '9')
	{
		return chr - '0';
	}

	if(chr >= 'A' && chr <= 'F')
	{
		return chr - 'A' + 0x0A;
	}

	// TODO �����C���Ȃ̂ŏ������������Ƃ���B�����f�[�^����������n�j�ɂ��邩�H

	_ASSERT(0 && "Err File Format");
	return 0;
}
