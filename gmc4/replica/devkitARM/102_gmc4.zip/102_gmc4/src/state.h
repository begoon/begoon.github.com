#ifndef __STATE_H__
#define __STATE_H__
#ifdef __cplusplus
extern "C" {
#endif


#include "libgba/gba.h"

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
EWRAM_CODE void StateInit(void);
EWRAM_CODE void StateExec(void);


#ifdef __cplusplus
}
#endif
#endif
