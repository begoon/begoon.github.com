#include "state.h"
#include "panel.h"
#include "beep.h"
#include "gmc.h"


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
EWRAM_CODE void StateInit(void)
{
	PanelInit();
	BeepInit();
	GmcInit();
}
//---------------------------------------------------------------------------
EWRAM_CODE void StateExec(void)
{
	PanelExec();
	GmcExec();
}
