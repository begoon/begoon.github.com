#ifndef __PANEL_H__
#define __PANEL_H__
#ifdef __cplusplus
extern "C" {
#endif


#include "libgba/gba.h"

//---------------------------------------------------------------------------
#define PANEL_GMC_BOTTON_WIDTH			5
#define PANEL_GMC_BOTTON_HEIGHT			4
#define PANEL_GMC_BOTTON_CNT			(PANEL_GMC_BOTTON_WIDTH * PANEL_GMC_BOTTON_HEIGHT)

enum {
	PANEL_GMC = 0x01,
	PANEL_MONITOR,
	PANEL_LOAD,
};

//---------------------------------------------------------------------------

typedef struct {
	u16 act;
	u16 actOld;

	// Gmc
	bool isHideLedHex;
	bool isDrawLedHex;
	bool isDrawLedBinary;
	bool isMoveCursor;
	s16  cursorIdx;

	// Monitor
	s16  listIdx;

	// Load
	bool isDrawFile;


} ST_PANEL;


typedef struct {
	u16   x;
	u16   y;
	u16   key;
	char* pStr;

} ST_PANEL_BUTTON_TABLE;


//---------------------------------------------------------------------------
EWRAM_CODE void PanelInit(void);

EWRAM_CODE void PanelExec(void);
EWRAM_CODE void PanelExecGmc(void);
EWRAM_CODE void PanelExecMonitor(void);
EWRAM_CODE void PanelExecLoad(void);

EWRAM_CODE void PanelCalcCursor(void);
EWRAM_CODE void PanelCalcList(void);
EWRAM_CODE void PanelCalcSelect(void);

EWRAM_CODE void PanelDrawHex(void);
EWRAM_CODE void PanelDrawBinary(void);
EWRAM_CODE void PanelDrawCursor(void);
IWRAM_CODE void PanelDrawReg(void);
IWRAM_CODE void PanelDrawData(void);
IWRAM_CODE void PanelDrawProgram(void);
IWRAM_CODE void PanelDrawFile(void);

EWRAM_CODE void PanelSetDrawLedHex(bool is);
EWRAM_CODE void PanelSetHideLedHex(bool is);
EWRAM_CODE void PanelSetDrawLedBinary(bool is);

EWRAM_CODE void PanelShowGmc(void);
EWRAM_CODE void PanelShowMonitor(void);
EWRAM_CODE void PanelShowFile(void);


#ifdef __cplusplus
}
#endif
#endif
