#include "gmc.h"
#include "panel.h"
#include "beep.h"


//---------------------------------------------------------------------------
ST_GMC_OP_TABLE GmcOpTable[GMC_MAX_OP_CNT] = {
	// op, size, pName, pFunc
	{ GMC_OP_KA,   1, "KA  ", (void*)GmcExecRunKa   },
	{ GMC_OP_AO,   1, "A0  ", (void*)GmcExecRunAo   },
	{ GMC_OP_CH,   1, "CH  ", (void*)GmcExecRunCh   },
	{ GMC_OP_CY,   1, "CY  ", (void*)GmcExecRunCy   },
	{ GMC_OP_AM,   1, "AM  ", (void*)GmcExecRunAm   },
	{ GMC_OP_MA,   1, "MA  ", (void*)GmcExecRunMa   },
	{ GMC_OP_MP,   1, "MP  ", (void*)GmcExecRunMp   },
	{ GMC_OP_MM,   1, "MM  ", (void*)GmcExecRunMm   },
	{ GMC_OP_TIA,  2, "TIA ", (void*)GmcExecRunTia  },
	{ GMC_OP_AIA,  2, "AIA ", (void*)GmcExecRunAia  },
	{ GMC_OP_TIY,  2, "TIY ", (void*)GmcExecRunTiy  },
	{ GMC_OP_AIY,  2, "AIY ", (void*)GmcExecRunAiy  },
	{ GMC_OP_CIA,  2, "CIA ", (void*)GmcExecRunCia  },
	{ GMC_OP_CIY,  2, "CIY ", (void*)GmcExecRunCiy  },
	{ GMC_OP_CAL,  2, "CAL ", (void*)GmcExecRunCal  },
	{ GMC_OP_JUMP, 3, "JUMP", (void*)GmcExecRunJump },
};

ST_GMC Gmc;


//---------------------------------------------------------------------------
EWRAM_CODE void GmcInit(void)
{
	_Memset(&Gmc, 0x00, sizeof(ST_GMC));

	GmcSetResetHardWare();
	Gmc.act = GMC_INPUT;
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcExec(void)
{
	switch(Gmc.act)
	{
	case GMC_INPUT:
		GmcExecInput();
		break;

	case GMC_RUN:
		GmcExecRun();
		break;

	case GMC_STEP:
		GmcExecStep();
		break;

	default:
		SystemError("[Err] GmcExec Gmc.act=%d\n", Gmc.act);
		break;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcExecInput(void)
{
	if(Gmc.isKeyTrg == FALSE)
	{
		return;
	}


	u8 oldKey = Gmc.keyBuf[Gmc.keyBufIdx];
	u8 key    = Gmc.keyBuf[Gmc.keyBufIdx ^ 0x01];

	u8 oldNum = Gmc.keyBufNum[Gmc.keyBufNumIdx];
	u8 num    = Gmc.keyBufNum[Gmc.keyBufNumIdx ^ 0x01];

	switch(key)
	{
	case GMC_KEY_0:
	case GMC_KEY_1:
	case GMC_KEY_2:
	case GMC_KEY_3:
	case GMC_KEY_4:
	case GMC_KEY_5:
	case GMC_KEY_6:
	case GMC_KEY_7:
	case GMC_KEY_8:
	case GMC_KEY_9:
	case GMC_KEY_A:
	case GMC_KEY_B:
	case GMC_KEY_C:
	case GMC_KEY_D:
	case GMC_KEY_E:
	case GMC_KEY_F:
		GmcSetEditHex(key);
		break;

	case GMC_KEY_A_SET:
		GmcSetEditHex2(oldNum, num);
		GmcSetEditAdr2(oldNum, num);
		break;

	case GMC_KEY_INCR: ;
		u8 adr = Gmc.editAdr;

		if(oldKey <= GMC_KEY_F)
		{
			Gmc.mem[adr] = Gmc.editHex;
		}
		adr++;

		GmcSetEditHex(Gmc.mem[adr]);
		GmcSetEditAdr(adr);
		break;

	case GMC_KEY_RUN:
		if(oldKey == GMC_KEY_1)
		{
			GmcSetReset();
			GmcSetEditHexOff();

			Gmc.act = GMC_RUN;
		}
/*
		else if(oldKey == GMC_KEY_2)
		{
		}
		else if(oldKey == GMC_KEY_5)
		{
		}
		else if(oldKey == GMC_KEY_6)
		{
		}
*/
		break;

	case GMC_KEY_RESET:
		GmcSetReset();
		break;

	default:
		SystemError("[Err] GmcExecInput key=%d\n", key);
		break;
	}
}
//---------------------------------------------------------------------------
IWRAM_CODE void GmcExecRun(void)
{
	if(Gmc.isKeyCnt == TRUE && Gmc.key == GMC_KEY_RESET)
	{
		Gmc.act = GMC_INPUT;
		GmcSetKeyTrg(Gmc.key);
		GmcExecInput();

		return;
	}


	s16 i;

	for(i=0; i<GMC_MAX_EXEC_VBLANK_CNT; i++)
	{
		if(BeepIsEnd() == FALSE)
		{
			break;
		}

		if(Gmc.wait != 0)
		{
			Gmc.wait--;
			break;
		}

		if(GmcIsPcArea() == FALSE)
		{
			Gmc.pc = 0x00;
		}

//		GmcDump();
		u8 op = GmcGetOp();
		GmcOpTable[op].pFunc();
	}
}
//---------------------------------------------------------------------------
// �����ꂽ�����L�[�i0�`F�j��Ar�ɑ�����܂�
IWRAM_CODE void GmcExecRunKa(void)
{
	if(Gmc.isKeyCnt == TRUE && Gmc.key <= GMC_KEY_F)
	{
		Gmc.mem[GMC_REG_A] = Gmc.key;
		Gmc.flag = 0;
	}
	else
	{
		Gmc.flag = 1;
	}

	Gmc.pc++;
}
//---------------------------------------------------------------------------
// Ar�̒l�𐔎�LED�ɓ_�����܂�
IWRAM_CODE void GmcExecRunAo(void)
{
	GmcSetEditHex(Gmc.mem[GMC_REG_A]);
	Gmc.flag = 1;

	Gmc.pc++;
}
//---------------------------------------------------------------------------
// Ar��Br�AYr��Zr�̒l���݂��ɓ���ւ��܂�
IWRAM_CODE void GmcExecRunCh(void)
{
	GmcSwapNum(GMC_REG_A, GMC_REG_B);
	GmcSwapNum(GMC_REG_Y, GMC_REG_Z);

	Gmc.flag = 1;
	Gmc.pc++;
}
//---------------------------------------------------------------------------
// Ar��Yr�̒l���݂��ɓ���ւ��܂�
IWRAM_CODE void GmcExecRunCy(void)
{
	GmcSwapNum(GMC_REG_A, GMC_REG_Y);

	Gmc.flag = 1;
	Gmc.pc++;
}
//---------------------------------------------------------------------------
// Ar�̒l���f�[�^�������i0x50+Yr�j�ɑ�����܂�
IWRAM_CODE void GmcExecRunAm(void)
{
	Gmc.mem[0x50 + Gmc.mem[GMC_REG_Y]] = Gmc.mem[GMC_REG_A];

	Gmc.flag = 1;
	Gmc.pc++;
}
//---------------------------------------------------------------------------
// �f�[�^�������i0x50+Yr�j�̒l��Ar�ɑ�����܂�
IWRAM_CODE void GmcExecRunMa(void)
{
	Gmc.mem[GMC_REG_A] = Gmc.mem[0x50 + Gmc.mem[GMC_REG_Y]];

	Gmc.flag = 1;
	Gmc.pc++;
}
//---------------------------------------------------------------------------
// �f�[�^�������i0x50+Yr�j��Ar�̒l�𑫂��܂�
IWRAM_CODE void GmcExecRunMp(void)
{
	u8 res = Gmc.mem[0x50 + Gmc.mem[GMC_REG_Y]] + Gmc.mem[GMC_REG_A];

	if(res >= 0x10)
	{
		res &= 0x0f;
		Gmc.flag = 1;
	}
	else
	{
		Gmc.flag = 0;
	}

	Gmc.mem[GMC_REG_A] = res;
	Gmc.pc++;
}
//---------------------------------------------------------------------------
// �f�[�^�������i0x50+Yr�j����Ar�̒l�������A���ʂ�Ar�ɑ�����܂�
IWRAM_CODE void GmcExecRunMm(void)
{
	u8 res = Gmc.mem[0x50 + Gmc.mem[GMC_REG_Y]] - Gmc.mem[GMC_REG_A];

	if(res & 0x80)
	{
		res &= 0x0f;
		Gmc.flag = 1;
	}
	else
	{
		Gmc.flag = 0;
	}

	Gmc.mem[GMC_REG_A] = res;
	Gmc.pc++;
}
//---------------------------------------------------------------------------
// �w�肵���l��Ar�ɑ�����܂�
IWRAM_CODE void GmcExecRunTia(void)
{
	Gmc.mem[GMC_REG_A] = Gmc.mem[Gmc.pc + 1];

	Gmc.flag = 1;
	Gmc.pc += 2;
}
//---------------------------------------------------------------------------
// �w�肵���l��Ar�ɑ����܂�
IWRAM_CODE void GmcExecRunAia(void)
{
	u8 res = Gmc.mem[GMC_REG_A] + Gmc.mem[Gmc.pc + 1];

	if(res >= 0x10)
	{
		res &= 0x0f;
		Gmc.flag = 1;
	}
	else
	{
		Gmc.flag = 0;
	}

	Gmc.mem[GMC_REG_A] = res;
	Gmc.pc += 2;
}
//---------------------------------------------------------------------------
// �w�肵���l��Yr�ɑ�����܂�
IWRAM_CODE void GmcExecRunTiy(void)
{
	Gmc.mem[GMC_REG_Y] = Gmc.mem[Gmc.pc + 1];

	Gmc.flag = 1;
	Gmc.pc += 2;
}
//---------------------------------------------------------------------------
// Yr�ɒl�𑫂��܂�
IWRAM_CODE void GmcExecRunAiy(void)
{
	u8 res = Gmc.mem[GMC_REG_Y] + Gmc.mem[Gmc.pc + 1];


	if(res >= 0x10)
	{
		res &= 0x0f;
		Gmc.flag = 1;
	}
	else
	{
		Gmc.flag = 0;
	}

	Gmc.mem[GMC_REG_Y] = res;
	Gmc.pc += 2;
}
//---------------------------------------------------------------------------
// Ar�̒l�����Ɠ����ꍇ�A��v�Ȃ���s�t���O=0�A��v���Ȃ��̂Ȃ�1�ɂȂ�܂�
IWRAM_CODE void GmcExecRunCia(void)
{
	if(Gmc.mem[GMC_REG_A] == Gmc.mem[Gmc.pc + 1])
	{
		Gmc.flag = 0;
	}
	else
	{
		Gmc.flag = 1;
	}

	Gmc.pc += 2;
}
//---------------------------------------------------------------------------
// Yr�̒l�����Ɠ����ꍇ�A��v�Ȃ���s�t���O=0�A��v���Ȃ��̂Ȃ�1�ɂȂ�܂�
IWRAM_CODE void GmcExecRunCiy(void)
{
	if(Gmc.mem[GMC_REG_Y] == Gmc.mem[Gmc.pc + 1])
	{
		Gmc.flag = 0;
	}
	else
	{
		Gmc.flag = 1;
	}

	Gmc.pc += 2;
}
//---------------------------------------------------------------------------
// �T�[�r�X�R�[�����Ăяo���܂�
IWRAM_CODE void GmcExecRunCal(void)
{
	if(Gmc.flag == 0)
	{
		Gmc.flag = 1;
		Gmc.pc += 2;

		return;
	}


	u8 num = Gmc.mem[Gmc.pc + 1];

	switch(num)
	{
	// ����LED���������܂�
	case 0x00:
		GmcSetEditHexOff();
		Gmc.flag = 1;
		break;

	// Yr�̒l��2�iLED�̈�ӏ���_�����܂�
	case 0x01:
		GmcSetEditAdrOn(Gmc.mem[GMC_REG_Y]);
		Gmc.flag = 1;
		break;

	// Yr�̒l��2�iLED�̈�ӏ����������܂�
	case 0x02:
		GmcSetEditAdrOff(Gmc.mem[GMC_REG_Y]);
		Gmc.flag = 1;
		break;

	// NOP�i�{���̓|�[�g�o�͂����AGMC-4�͖��Ή��j
	case 0x03:
		// EMPTY
		break;

	// Ar�̒l���r�b�g���]���܂�
	case 0x04:
		Gmc.mem[GMC_REG_A] = (~Gmc.mem[GMC_REG_A]) & 0x0f;
		Gmc.flag = 1;
		break;

	// Ar/Br/Yr/Zr �� Ar'/Br'/Yr'/Zr' �����ւ��܂�
	case 0x05:
		GmcSwapNum(GMC_REG_A, GMC_REG_A2);
		GmcSwapNum(GMC_REG_B, GMC_REG_B2);
		GmcSwapNum(GMC_REG_Y, GMC_REG_Y2);
		GmcSwapNum(GMC_REG_Z, GMC_REG_Z2);
		Gmc.flag = 1;
		break;

	// Ar��1�r�b�g�E�V�t�g���܂��B���̒l�������Ȃ���s�t���O=1�A��Ȃ�0
	case 0x06:
		if(Gmc.mem[GMC_REG_A] & 0x01)
		{
			Gmc.flag = 0;
		}
		else
		{
			Gmc.flag = 1;
		}

		Gmc.mem[GMC_REG_A] >>= 1;
		break;

	// �G���h����炵�܂�
	case 0x07:
		BeepPlayEnd();
		Gmc.flag = 1;
		break;

	// �G���[����炵�܂�
	case 0x08:
		BeepPlayErr();
		Gmc.flag = 1;
		break;

	// �u�s�b�v�Ƃ����Z������炵�܂�
	case 0x09:
		BeepPlayPiShort();
		Gmc.flag = 1;
		break;

	// �u�s�[�v�Ƃ�����������炵�܂�
	case 0x0a:
		BeepPlayPiLong();
		Gmc.flag = 1;
		break;

	// Ar�Ŏw�肵�����K�i1�`E�j�̉���炷
	case 0x0b:
		BeepPlayTone(Gmc.mem[GMC_REG_A]);
		Gmc.flag = 1;
		break;

	// �w�肵�����Ԃ����҂B�҂����Ԃ́A(Ar + 1) * 0.1 �b�B�R�[�h��+1�́A���݂̖��ߕ���VBLANK
	case 0x0c:
		Gmc.wait = (Gmc.mem[GMC_REG_A] + 1) * 6 + 1;
		Gmc.flag = 1;
		break;

	// �f�[�^�������̒l��2�iLED�ɓ_������B���3�r�b�g��5F�Ԓn�A����4�r�b�g��5E�Ԓn�̒l���g�p���܂�
	case 0x0d:
		GmcSetEditAdr2(Gmc.mem[0x5f], Gmc.mem[0x5e]);
		Gmc.flag = 1;
		break;

	// CAL DEM-
	case 0x0e:
		{
			u8 rY  = Gmc.mem[GMC_REG_Y];
			u8 rA  = Gmc.mem[GMC_REG_A];
			u8 tmp = Gmc.mem[0x50 + rY];

			if(tmp < rA)
			{
				Gmc.mem[0x50 + ((rY - 1) & 0x0f)] = 0x01;
				Gmc.mem[0x50 + rY] = (10 + tmp - rA) & 0x0f;
			}
			else
			{
				Gmc.mem[0x50 + rY] = tmp - rA;
			}

			Gmc.mem[GMC_REG_Y] = (rY - 1) & 0x0f;
			Gmc.flag = 1;
		}
		break;

	// CAL DEM+
	case 0x0f:
		{
			u8 idx = Gmc.mem[GMC_REG_Y];
			u8 val = Gmc.mem[0x50 + idx] + Gmc.mem[GMC_REG_A];

			while(val >= 10)
			{
				Gmc.mem[0x50 + idx] = (val - 10) & 0x0f;

				idx = (idx - 1) & 0x0f;
				val = Gmc.mem[0x50 + idx] + 0x01;
			}

			Gmc.mem[0x50 + idx] = val;
			Gmc.mem[GMC_REG_Y]  = (Gmc.mem[GMC_REG_Y] - 1) & 0x0f;
			Gmc.flag = 1;
		}
		break;

	default:
		SystemError("[Err] GmcExecRunCal num=%d pc=%d\n", num, Gmc.pc + 1);
		break;
	}

	Gmc.pc += 2;
}
//---------------------------------------------------------------------------
// ���s�t���O=1�̏ꍇ�A�w�肵���A�h���X�ɃW�����v���܂�
IWRAM_CODE void GmcExecRunJump(void)
{
	u8 adr1 = Gmc.mem[Gmc.pc + 1];
	u8 adr2 = Gmc.mem[Gmc.pc + 2];

	if(Gmc.flag == 1)
	{
		Gmc.pc = (adr1 << 4) | adr2;
	}
	else
	{
		Gmc.pc += 3;
		Gmc.flag = 1;
	}
}
//---------------------------------------------------------------------------
IWRAM_CODE void GmcExecStep(void)
{
	// TODO
}
//---------------------------------------------------------------------------
IWRAM_CODE u8 GmcGetOp(void)
{
	u8 op = Gmc.mem[Gmc.pc];
	_ASSERT(op <= GMC_OP_JUMP);

	return op;
}
//---------------------------------------------------------------------------
IWRAM_CODE u8 GmcGetOpSize(void)
{
	u8 op = GmcGetOp();

	return GmcOpTable[op].size;
}
//---------------------------------------------------------------------------
IWRAM_CODE u8 GmcGetOpSize2(u16 adr)
{
	return GmcOpTable[Gmc.mem[adr]].size;
}
//---------------------------------------------------------------------------
IWRAM_CODE bool GmcIsPcArea(void)
{
	if(Gmc.pc >= 0x50)
	{
		return FALSE;
	}

	if(Gmc.pc + GmcGetOpSize() > 0x50)
	{
		return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetKeyTrg(u16 key)
{
	if(Gmc.act == GMC_RUN)
	{
		return;
	}


	if(key <= GMC_KEY_F)
	{
		Gmc.keyBufNum[Gmc.keyBufNumIdx] = key;
		Gmc.keyBufNumIdx ^= 0x01;
	}

	Gmc.keyBuf[Gmc.keyBufIdx] = key;
	Gmc.keyBufIdx ^= 0x01;


	BeepPlayPush();

	Gmc.isKeyTrg = TRUE;
	PanelSetDrawLedBinary(TRUE);
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetKeyTrg2(bool is)
{
	Gmc.isKeyTrg = is;
	PanelSetDrawLedBinary(TRUE);
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetKeyCnt(u16 key)
{
	Gmc.key = key;
	Gmc.isKeyCnt = TRUE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetKeyCnt2(bool is)
{
	Gmc.isKeyCnt = is;
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetEditHex(u8 num)
{
	Gmc.editHex = num;

	PanelSetDrawLedHex(TRUE);
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetEditHex2(u8 numHi, u8 numLo)
{
	Gmc.editHex = Gmc.mem[((numHi & 0x0F) << 4) | (numLo & 0x0F)];

	PanelSetDrawLedHex(TRUE);
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetEditHexOff(void)
{
	PanelSetHideLedHex(TRUE);
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetEditAdr(u8 num)
{
	Gmc.editAdr = num;

	PanelSetDrawLedBinary(TRUE);
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetEditAdr2(u8 numHi, u8 numLo)
{
	Gmc.editAdr = ((numHi & 0x07) << 4) | (numLo & 0x0f);

	PanelSetDrawLedBinary(TRUE);
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetEditAdrOn(u8 num)
{
	if(num >= 0x07)
	{
		return;
	}

	Gmc.editAdr |= GmcGetNumBit(num);
	PanelSetDrawLedBinary(TRUE);
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetEditAdrOff(u8 num)
{
	if(num >= 0x07)
	{
		return;
	}

	Gmc.editAdr &= ~GmcGetNumBit(num);
	PanelSetDrawLedBinary(TRUE);
}
//---------------------------------------------------------------------------
EWRAM_CODE u8 GmcGetNumBit(u8 num)
{
	_ASSERT(num < 0x07);


	u8 t[7] = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40 };

	return t[num];
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSwapNum(u8 adrA, u8 adrB)
{
	u8 tmp = Gmc.mem[adrA];

	Gmc.mem[adrA] = Gmc.mem[adrB];
	Gmc.mem[adrB] = tmp;
}
//---------------------------------------------------------------------------
EWRAM_CODE u8 GmcGetMem(u16 adr)
{
	_ASSERT(adr < GMC_MAX_MEM_CNT);


	return Gmc.mem[adr];
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetMem(u16 adr, u8 hex)
{
	_ASSERT(adr < GMC_MAX_MEM_CNT);
	_ASSERT(hex < 0x10);


	Gmc.mem[adr] = hex;
}
//---------------------------------------------------------------------------
EWRAM_CODE u8 GmcGetMemData(u16 idx)
{
	return GmcGetMem(0x50 + idx);
}
//---------------------------------------------------------------------------
EWRAM_CODE u8 GmcGetReg(u16 idx)
{
	_ASSERT(idx < 8);


	u8 pat[] = { GMC_REG_A, GMC_REG_A2, GMC_REG_B, GMC_REG_B2, GMC_REG_Y, GMC_REG_Y2, GMC_REG_Z, GMC_REG_Z2 };

	return GmcGetMem(pat[idx]);
}
//---------------------------------------------------------------------------
EWRAM_CODE u8 GmcGetPc(void)
{
	return Gmc.pc;
}
//---------------------------------------------------------------------------
EWRAM_CODE u8 GmcGetFlag(void)
{
	return Gmc.flag;
}
//---------------------------------------------------------------------------
EWRAM_CODE u16 GmcGetLedHex(void)
{
	return Gmc.editHex;
}
//---------------------------------------------------------------------------
EWRAM_CODE u16 GmcGetLedBinary(void)
{
	return Gmc.editAdr;
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetReset(void)
{
	Gmc.pc = 0;
	Gmc.flag = 0;
	Gmc.wait = 0;

	GmcSetEditHex(Gmc.mem[0]);
	GmcSetEditAdr(0x00);
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcSetResetHardWare(void)
{
	GmcSetReset();

	_Memset(&Gmc.mem, 0x0f, GMC_MAX_MEM_CNT);
}
//---------------------------------------------------------------------------
EWRAM_CODE char* GmcGetOpName(u16 adr)
{
	return GmcOpTable[Gmc.mem[adr]].pName;
}
//---------------------------------------------------------------------------
EWRAM_CODE bool GmcIsKeyTrg(void)
{
	return Gmc.isKeyTrg;
}
//---------------------------------------------------------------------------
EWRAM_CODE bool GmcIsKeyCnt(void)
{
	return Gmc.isKeyCnt;
}
//---------------------------------------------------------------------------
EWRAM_CODE void GmcDump(void)
{
	s16 i;

	TRACEOUT("--------------------\n");
	TRACEOUT("PC:%02X OP:%02X %s\n", Gmc.pc, GmcGetOp(), GmcGetOpName(Gmc.pc));

	for(i=0; i<8; i++)
	{
		TRACEOUT("R[%01X]: %02X\n", i, GmcGetReg(i));
	}

	for(i=0; i<0x0f; i++)
	{
		TRACEOUT("M[%01X]: %02X\n", i, GmcGetMem(0x50 + i));
	}
}
