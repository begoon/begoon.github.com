#ifndef __GMC_H__
#define __GMC_H__
#ifdef __cplusplus
extern "C" {
#endif


#include "libgba/gba.h"

//---------------------------------------------------------------------------
#define GMC_MAX_OP_CNT				0x10
#define GMC_MAX_MEM_CNT				0x100
#define GMC_MAX_KEY_BUF_CNT			2
#define GMC_MAX_KEY_BUF_NUM_CNT		2
#define GMC_MAX_EXEC_VBLANK_CNT		5
#define GMC_REG_A					0x6f
#define GMC_REG_A2					0x69
#define GMC_REG_B					0x6c
#define GMC_REG_B2					0x67
#define GMC_REG_Y					0x6e
#define GMC_REG_Y2					0x68
#define GMC_REG_Z					0x6d
#define GMC_REG_Z2					0x66


// ���[�h
enum {
	GMC_INIT = 0x01,
	GMC_INPUT,
	GMC_RUN,
	GMC_STEP,
};


// ���߃Z�b�g
enum {
	GMC_OP_KA = 0x00,
	GMC_OP_AO,
	GMC_OP_CH,
	GMC_OP_CY,
	GMC_OP_AM,
	GMC_OP_MA,
	GMC_OP_MP,
	GMC_OP_MM,
	GMC_OP_TIA,
	GMC_OP_AIA,
	GMC_OP_TIY,
	GMC_OP_AIY,
	GMC_OP_CIA,
	GMC_OP_CIY,
	GMC_OP_CAL,
	GMC_OP_JUMP,
};

// �L�[�Z�b�g
enum {
	GMC_KEY_0 = 0x00,
	GMC_KEY_1,
	GMC_KEY_2,
	GMC_KEY_3,
	GMC_KEY_4,
	GMC_KEY_5,
	GMC_KEY_6,
	GMC_KEY_7,
	GMC_KEY_8,
	GMC_KEY_9,
	GMC_KEY_A,
	GMC_KEY_B,
	GMC_KEY_C,
	GMC_KEY_D,
	GMC_KEY_E,
	GMC_KEY_F,
	GMC_KEY_A_SET,
	GMC_KEY_INCR,
	GMC_KEY_RUN,
	GMC_KEY_RESET,
};

//---------------------------------------------------------------------------

typedef struct {
	u16  act;									// ���[�h

	u8   mem[GMC_MAX_MEM_CNT];
	u8   pc;
	u8   flag;
	u16  wait;									// vsync�Ɠ����i60��1�b�j

	u8   editHex;								// 16�iLED�ƑΉ�
	u8   editAdr;								//  2�iLED�ƑΉ�

	bool isKeyTrg;								// �{�^���̗L���i�����ꂽ�Ƃ��̂ݐ^�j
	bool isKeyCnt;								// �{�^���̗L���i������Ă���Ƃ��^�j
	u8   key;									// ������Ă���{�^�����i�[
	u8   keyBuf[GMC_MAX_KEY_BUF_CNT];			// �����ꂽ�{�^���̃o�b�t�@
	u8   keyBufIdx;
	u8   keyBufNum[GMC_MAX_KEY_BUF_NUM_CNT];	// �����ꂽ�{�^���̃o�b�t�@�i���l�̂݁j
	u8   keyBufNumIdx;

	bool isRunLed;								// RUN���[�h����2�iLED�̗L���i�A�h���X�\������Ƃ��^�j
} ST_GMC;


typedef struct {
	u8    op;
	u8    size;
	char* pName;
	void  (*pFunc)(void);
} ST_GMC_OP_TABLE;


//---------------------------------------------------------------------------
EWRAM_CODE void  GmcInit(void);

//----
EWRAM_CODE void  GmcExec(void);
EWRAM_CODE void  GmcExecInput(void);
IWRAM_CODE void  GmcExecRun(void);
IWRAM_CODE void  GmcExecRunKa(void);
IWRAM_CODE void  GmcExecRunAo(void);
IWRAM_CODE void  GmcExecRunCh(void);
IWRAM_CODE void  GmcExecRunCy(void);
IWRAM_CODE void  GmcExecRunAm(void);
IWRAM_CODE void  GmcExecRunMa(void);
IWRAM_CODE void  GmcExecRunMp(void);
IWRAM_CODE void  GmcExecRunMm(void);
IWRAM_CODE void  GmcExecRunTia(void);
IWRAM_CODE void  GmcExecRunAia(void);
IWRAM_CODE void  GmcExecRunTiy(void);
IWRAM_CODE void  GmcExecRunAiy(void);
IWRAM_CODE void  GmcExecRunCia(void);
IWRAM_CODE void  GmcExecRunCiy(void);
IWRAM_CODE void  GmcExecRunCal(void);
IWRAM_CODE void  GmcExecRunJump(void);
IWRAM_CODE void  GmcExecStep(void);
IWRAM_CODE u8    GmcGetOp(void);
IWRAM_CODE u8    GmcGetOpSize(void);
IWRAM_CODE u8    GmcGetOpSize2(u16 adr);
IWRAM_CODE bool  GmcIsPcArea(void);

//----
EWRAM_CODE void  GmcSetKeyTrg(u16 key);
EWRAM_CODE void  GmcSetKeyTrg2(bool is);
EWRAM_CODE void  GmcSetKeyCnt(u16 key);
EWRAM_CODE void  GmcSetKeyCnt2(bool is);
EWRAM_CODE void  GmcSetEditHex(u8 num);
EWRAM_CODE void  GmcSetEditHex2(u8 numHi, u8 numLo);
EWRAM_CODE void  GmcSetEditHexOff(void);
EWRAM_CODE void  GmcSetEditAdr(u8 num);
EWRAM_CODE void  GmcSetEditAdr2(u8 numHi, u8 numLo);
EWRAM_CODE void  GmcSetEditAdrOn(u8 num);
EWRAM_CODE void  GmcSetEditAdrOff(u8 num);
EWRAM_CODE u8    GmcGetNumBit(u8 num);
EWRAM_CODE void  GmcSwapNum(u8 adrA, u8 adrB);

//----
EWRAM_CODE u8    GmcGetMem(u16 adr);
EWRAM_CODE void  GmcSetMem(u16 adr, u8 hex);
EWRAM_CODE u8    GmcGetMemData(u16 idx);
EWRAM_CODE u8    GmcGetReg(u16 idx);
EWRAM_CODE u8    GmcGetPc(void);
EWRAM_CODE u8    GmcGetFlag(void);
EWRAM_CODE u16   GmcGetLedHex(void);
EWRAM_CODE u16   GmcGetLedBinary(void);
EWRAM_CODE void  GmcSetReset(void);
EWRAM_CODE void  GmcSetResetHardWare(void);
EWRAM_CODE char* GmcGetOpName(u16 adr);

EWRAM_CODE bool  GmcIsKeyTrg(void);
EWRAM_CODE bool  GmcIsKeyCnt(void);

//----
EWRAM_CODE void  GmcDump(void);


#ifdef __cplusplus
}
#endif
#endif
