#ifndef __FILE_H__
#define __FILE_H__
#ifdef __cplusplus
extern "C" {
#endif


#include "libgba/gba.h"

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

typedef struct {
	s16 idx;			// GBFS�̃t�@�C���C���f�b�N�X

} ST_FILE;

//---------------------------------------------------------------------------
EWRAM_CODE void  FileInit(void);
EWRAM_CODE void  FileExec(void);

EWRAM_CODE void  FileLoadIdx(void);
EWRAM_CODE void  FileNextIdx(void);
EWRAM_CODE void  FilePrevIdx(void);
EWRAM_CODE char* FileGetName(void);
EWRAM_CODE u8    FileGetHex(char chr);


#ifdef __cplusplus
}
#endif
#endif
