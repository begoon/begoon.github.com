#ifndef __BEEP_H__
#define __BEEP_H__
#ifdef __cplusplus
extern "C" {
#endif


#include "libgba/gba.h"

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

typedef struct {
	bool isOn;					// ���̗L��

} ST_BEEP;

//---------------------------------------------------------------------------
EWRAM_CODE void BeepInit(void);
EWRAM_CODE void BeepExec(void);

EWRAM_CODE void BeepSetOn(void);
EWRAM_CODE void BeepSetOff(void);

EWRAM_CODE void BeepPlayPush(void);
EWRAM_CODE void BeepPlayEnd(void);
EWRAM_CODE void BeepPlayErr(void);
EWRAM_CODE void BeepPlayPiShort(void);
EWRAM_CODE void BeepPlayPiLong(void);
EWRAM_CODE void BeepPlayTone(u8 num);

EWRAM_CODE bool BeepIsEnd(void);


#ifdef __cplusplus
}
#endif
#endif
