#ifndef __RES_H__
#define __RES_H__


// bg
#include "res/bg_ascii.h"
#include "res/bg_gmc.h"
#include "res/bg_monitor.h"


// spr
#include "res/spr_item.h"
#define RES_SPR_CURSOR_NUM				5
#define RES_SPR_CURSOR_PUSH_NUM			9

// snd
// EMPTY


// dat
// EMPTY




#endif
