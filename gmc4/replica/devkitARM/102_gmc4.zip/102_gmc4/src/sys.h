#ifndef __SYS_H__
#define __SYS_H__
#ifdef __cplusplus
extern "C" {
#endif


#include "libgba/gba.h"

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
EWRAM_CODE void SysInit(void);
EWRAM_CODE void SysExec(void);


#ifdef __cplusplus
}
#endif
#endif
