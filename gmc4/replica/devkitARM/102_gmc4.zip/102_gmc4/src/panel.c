#include "panel.h"
#include "libmy/bg.h"
#include "libmy/spr.h"
#include "libmy/key.h"
#include "gmc.h"
#include "file.h"


//---------------------------------------------------------------------------

ST_PANEL_BUTTON_TABLE PanelButtonTable[] = {
	//  x,   y, enum,          str
	{  72, 116, GMC_KEY_0,     "0    "},
	{ 104, 116, GMC_KEY_1,     "1    "},
	{ 136, 116, GMC_KEY_2,     "2    "},
	{ 168, 116, GMC_KEY_3,     "3    "},
	{ 200, 116, GMC_KEY_RESET, "RESET"},

	{  72,  92, GMC_KEY_4,     "4    "},
	{ 104,  92, GMC_KEY_5,     "5    "},
	{ 136,  92, GMC_KEY_6,     "6    "},
	{ 168,  92, GMC_KEY_7,     "7    "},
	{ 200,  92, GMC_KEY_RUN,   "RUN  "},

	{  72,  68, GMC_KEY_8,     "8    "},
	{ 104,  68, GMC_KEY_9,     "9    "},
	{ 136,  68, GMC_KEY_A,     "A    "},
	{ 168,  68, GMC_KEY_B,     "B    "},
	{ 200,  68, GMC_KEY_INCR,  "INCR "},

	{  72,  44, GMC_KEY_C,     "C    "},
	{ 104,  44, GMC_KEY_D,     "D    "},
	{ 136,  44, GMC_KEY_E,     "E    "},
	{ 168,  44, GMC_KEY_F,     "F    "},
	{ 200,  44, GMC_KEY_A_SET, "A SET"},
};

ST_PANEL Panel;

//---------------------------------------------------------------------------
EWRAM_CODE void PanelInit(void)
{
	_Memset(&Panel, 0x00, sizeof(ST_PANEL));

	PanelShowGmc();
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelExec(void)
{
	switch(Panel.act)
	{
	case PANEL_GMC:
		PanelExecGmc();
		break;

	case PANEL_MONITOR:
		PanelExecMonitor();
		break;

	case PANEL_LOAD:
		PanelExecLoad();
		break;

	default:
		SystemError("[Err] PanelExec Panel.act=%d\n", Panel.act);
		break;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelExecGmc(void)
{
	PanelDrawCursor();
	PanelDrawHex();
	PanelDrawBinary();

	PanelCalcCursor();
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelExecMonitor(void)
{
	PanelDrawReg();
	PanelDrawData();
	PanelDrawProgram();

	PanelCalcList();
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelExecLoad(void)
{
	PanelDrawFile();

	PanelCalcSelect();
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelCalcCursor(void)
{
	// ��������
	u16 cnt = KeyGetCnt();
	u16 trg = KeyGetTrg();
	u8  key = PanelButtonTable[Panel.cursorIdx].key;

	if(cnt & KEY_A)
	{
		if(trg & KEY_A)
		{
			GmcSetKeyTrg(key);
		}
		else
		{
			GmcSetKeyTrg2(FALSE);
		}

		GmcSetKeyCnt(key);
		return;
	}
	GmcSetKeyCnt2(FALSE);


	// �ړ�����
	u16 rep = KeyGetRep();
	s16 cursorIdx = Panel.cursorIdx;

	if(rep & KEY_RIGHT)
	{
		cursorIdx++;
	}

	if(rep & KEY_LEFT)
	{
		cursorIdx--;
	}

	if(rep & KEY_UP)
	{
		cursorIdx += PANEL_GMC_BOTTON_WIDTH;
	}

	if(rep & KEY_DOWN)
	{
		cursorIdx -= PANEL_GMC_BOTTON_WIDTH;
	}


	if(cursorIdx >= PANEL_GMC_BOTTON_CNT)
	{
		cursorIdx -= PANEL_GMC_BOTTON_CNT;
	}
	else if(cursorIdx < 0)
	{
		cursorIdx += PANEL_GMC_BOTTON_CNT;
	}


	if(cursorIdx != Panel.cursorIdx)
	{
		Panel.cursorIdx = cursorIdx;
		Panel.isMoveCursor = TRUE;

		return;
	}


	// ���[�h�ύX����
	if(trg & KEY_R)
	{
		PanelShowMonitor();
		return;
	}

	if(trg & KEY_START)
	{
		PanelShowFile();
		return;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelCalcList(void)
{
	// �A�h���X�ړ�
	u16 rep = KeyGetRep();
	s16 listIdx = Panel.listIdx;

	if(rep & KEY_RIGHT)
	{
		listIdx += 0x10;
	}

	if(rep & KEY_LEFT)
	{
		listIdx -= 0x10;
	}

	if(rep & KEY_UP)
	{
		listIdx--;
	}

	if(rep & KEY_DOWN)
	{
		listIdx++;
	}


	if(listIdx >= (0x60 - 0x10))
	{
		listIdx = (0x60 - 0x10);
	}
	else if(listIdx < 0)
	{
		listIdx = 0;
	}

	if(listIdx != Panel.listIdx)
	{
		Panel.listIdx = listIdx;
		return;
	}


	// ���[�h�ύX����
	u16 trg = KeyGetTrg();

	if(trg & KEY_R)
	{
		PanelShowGmc();
		return;
	}

	if(trg & KEY_START)
	{
		PanelShowFile();
		return;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelCalcSelect(void)
{
	// �t�@�C���̌��� & ���[�h�ύX����
	u16 off = KeyGetOff();

	if(off & KEY_A || off & KEY_B)
	{
		if(off & KEY_A)
		{
			FileLoadIdx();
		}

		if(Panel.actOld == PANEL_GMC)
		{
			PanelShowGmc();
		}
		else
		{
			PanelShowMonitor();
		}

		return;
	}

	// �t�@�C���Z���N�g
	u16 rep = KeyGetRep();

	if(rep & KEY_DOWN)
	{
		FileNextIdx();

		Panel.isDrawFile = TRUE;
	}
	else if(rep & KEY_UP)
	{
		FilePrevIdx();

		Panel.isDrawFile = TRUE;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelDrawHex(void)
{
	if(Panel.isDrawLedHex == FALSE)
	{
		return;
	}
	Panel.isDrawLedHex = FALSE;


	if(Panel.isHideLedHex == FALSE)
	{
		u16 hex = GmcGetLedHex();
		SprSetHex(hex);

		return;
	}
	Panel.isHideLedHex = FALSE;


	SprLedHexHide();
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelDrawBinary(void)
{
	if(Panel.isDrawLedBinary == FALSE)
	{
		return;
	}
	Panel.isDrawLedBinary = FALSE;


	u16 binary = GmcGetLedBinary();
	if(GmcIsKeyTrg() == TRUE)
	{
		binary |= 0x08;
	}

	SprSetBinary(binary);
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelDrawCursor(void)
{
	if(Panel.isMoveCursor == TRUE)
	{
		Panel.isMoveCursor = FALSE;

		u16 x = PanelButtonTable[Panel.cursorIdx].x;
		u16 y = PanelButtonTable[Panel.cursorIdx].y;

		SprCursorMove(x, y);
		BgDrawStr(0, 19, PanelButtonTable[Panel.cursorIdx].pStr);
	}


	if(GmcIsKeyCnt() != SprCursorIsPush())
	{
		SprCursorChgShape();
	}
}
//---------------------------------------------------------------------------
IWRAM_CODE void PanelDrawReg(void)
{
	s16 i;

	// Ar �` Zr'
	for(i=0; i<4; i++)
	{
		BgDrawVal(6, 2 + (i*3), "%01X", GmcGetReg(i*2 + 0));
		BgDrawVal(6, 3 + (i*3), "%01X", GmcGetReg(i*2 + 1));
	}

	// PC
	BgDrawVal(5, 14, "%02X", GmcGetPc());

	// Flag
	BgDrawVal(6, 16, "%01X", GmcGetFlag());
}
//---------------------------------------------------------------------------
IWRAM_CODE void PanelDrawData(void)
{
	s16 i;

	for(i=0; i<0x10; i++)
	{
		BgDrawVal(11, 2 + i, "%01X", GmcGetMemData(i));
	}
}
//---------------------------------------------------------------------------
IWRAM_CODE void PanelDrawProgram(void)
{
	// TODO GMC�̃������\�����I�o���Ă�
	// TODO ���̊֐���VCOUNT=28������Ă���B�Ó�������

	s16 i;

	bool isSym[0x60];

	for(i=0; i<0x60; i++)
	{
		isSym[i] = FALSE;
	}

	i = 0;
	while(i < 0x60)
	{
		isSym[i] = TRUE;
		i += GmcGetOpSize2(i);
	}

	s16 adr;

	for(i=0; i<16; i++)
	{
		adr = Panel.listIdx + i;

		// addr
		BgDrawVal(14, 2 + i, "%02X", adr);

		// code
		BgDrawVal(18, 2 + i, "%01X", GmcGetMem(adr));

		// sym
		if(isSym[adr] == TRUE)
		{
			BgDrawStr(22, 2 + i, GmcGetOpName(adr));
		}
		else
		{
			BgDrawVal(22, 2 + i, "<%01X> ", GmcGetMem(adr));
		}
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelDrawFile(void)
{
	if(Panel.isDrawFile == FALSE)
	{
		return;
	}
	Panel.isDrawFile = FALSE;

	BgDrawStr( 0, 19, "Select File:                  ");
	BgDrawStr(13, 19, FileGetName());
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelSetDrawLedHex(bool is)
{
	Panel.isDrawLedHex = is;
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelSetHideLedHex(bool is)
{
	PanelSetDrawLedHex(is);
	Panel.isHideLedHex = is;
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelSetDrawLedBinary(bool is)
{
	Panel.isDrawLedBinary = is;
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelShowGmc(void)
{
	BgSetDatGmc();
	BgDrawCls();

	Panel.isHideLedHex = FALSE;
	Panel.isDrawLedHex = TRUE;
	Panel.isDrawLedBinary = TRUE;
	Panel.isMoveCursor = TRUE;

	PanelDrawHex();
	PanelDrawBinary();
	PanelDrawCursor();

	Panel.act = PANEL_GMC;
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelShowMonitor(void)
{
	BgSetDatMonitor();
	BgDrawCls();

	SprLedHexHide();
	SprLedBinaryHide();
	SprCursorHide();

	Panel.act = PANEL_MONITOR;
}
//---------------------------------------------------------------------------
EWRAM_CODE void PanelShowFile(void)
{
	Panel.isDrawFile = TRUE;
	PanelDrawFile();

	Panel.actOld = Panel.act;
	Panel.act = PANEL_LOAD;
}
